import { useState } from "react";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "../components/ui/card";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../lib/firebase";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("تم تسجيل الدخول بنجاح");
      // هنا تقدر تضيف redirect مثلاً navigate("/") لو عندك react-router
    } catch (error) {
      alert("اسم المستخدم أو كلمة المرور غير صحيحة");
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Card className="w-full max-w-sm shadow-lg">
        <CardHeader>
          <CardTitle className="text-center">تسجيل الدخول</CardTitle>
        </CardHeader>
       <p className="text-sm text-center">
  ماعندكش حساب؟{" "}
  <a href="/signup" className="text-blue-600 hover:underline">سجّل الآن</a>
</p>
 <CardContent className="space-y-4">
          <Input
            placeholder="البريد الإلكتروني"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            type="password"
            placeholder="كلمة المرور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button className="w-full" onClick={handleLogin}>
            دخول
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
