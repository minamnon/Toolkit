import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import PWAInstallPrompt from "@/components/PWAInstallPrompt";
import OfflineIndicator from "@/components/OfflineIndicator";

import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/LoginPage";
import SignUpPage from "@/pages/signup"; // ✅ تم إضافة صفحة التسجيل

function Router() {
  return (
    <Switch>
      <Route path="/signup" component={SignUpPage} />      {/* ✅ التسجيل */}
      <Route path="/login" component={LoginPage} />        {/* تسجيل الدخول */}
      <Route path="/" component={Home} />                  {/* الصفحة الرئيسية */}
      <Route component={NotFound} />                       {/* 404 */}
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <OfflineIndicator />
        <Router />
        <PWAInstallPrompt />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
