import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyA47y28spqdhwfZqOcw8QNfzDYK6EGZxQ0",
  authDomain: "distillerytollkit.firebaseapp.com",
  projectId: "distillerytollkit",
  storageBucket: "distillerytollkit.appspot.com",
  messagingSenderId: "1040177306248",
  appId: "1:1040177306248:web:817ba49e48f338a896dd3d",
  measurementId: "G-H04MNCSV8V"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firestore and Auth
export const db = getFirestore(app);
export const auth = getAuth(app);
