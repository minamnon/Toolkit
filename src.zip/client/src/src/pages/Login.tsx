import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent } from "@/components/ui/card";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // تحقق من اسم المستخدم والباسورد هنا
    if (username === "admin" && password === "1234") {
      alert("تم تسجيل الدخول بنجاح ✅");
      // هنا نعمل redirect أو نحفظ حالة المستخدم
    } else {
      alert("اسم المستخدم أو كلمة المرور غير صحيحة ❌");
    }
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center flex items-center justify-center"
      style={{ backgroundImage: "url('/login-bg.jpg')" }}
    >
      <Card className="bg-white/80 shadow-lg backdrop-blur-md w-full max-w-md">
        <CardHeader className="text-center text-2xl font-bold text-primary">
          تسجيل الدخول
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <Input
              placeholder="اسم المستخدم"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <Input
              type="password"
              placeholder="كلمة المرور"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Button type="submit" className="w-full">
              دخول
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
