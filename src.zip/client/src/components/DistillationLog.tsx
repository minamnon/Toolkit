import { useState, useMemo } from "react"; import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"; import { Card, CardContent, CardHeader, CardTitle, } from "@/components/ui/card"; import { Input } from "@/components/ui/input"; import { Label } from "@/components/ui/label"; import { Button } from "@/components/ui/button"; import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "@/components/ui/select"; import { Download } from "lucide-react"; import { useToast } from "@/hooks/use-toast"; import { exportToExcel } from "@/lib/export"; import { db } from "@/lib/firebase"; import { collection, addDoc, setDoc, getDocs, deleteDoc, doc, } from "firebase/firestore"; import type { DistillationOperation, InsertDistillationOperation, } from "@shared/schema";

export default function DistillationLog() { const [formData, setFormData] = useState({ operatorName: "", towerType: "", operationDate: new Date().toISOString().split("T")[0], operationTime: new Date().toTimeString().slice(0, 5), heads: "", tails: "", vinasse: "", vinasseLoading: "", alcohol96: "", convertedAlcohol: "", feedAmount: "", productionAmount: "", operationHours: "", });

const [editId, setEditId] = useState<string | null>(null); const [searchFilters, setSearchFilters] = useState({ shift: "", date: "" }); const { toast } = useToast(); const queryClient = useQueryClient();

const { data: operations = [], isLoading } = useQuery<DistillationOperation[]>({ queryKey: ["distillation-operations"], queryFn: async () => { const snapshot = await getDocs(collection(db, "distillation-operations")); return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as DistillationOperation[]; }, });

const saveMutation = useMutation({ mutationFn: async (data: InsertDistillationOperation & { id?: string }) => { if (data.id) { await setDoc(doc(db, "distillation-operations", data.id), data); return { id: data.id }; } else { const docRef = await addDoc(collection(db, "distillation-operations"), data); return { id: docRef.id }; } }, onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["distillation-operations"] }); setFormData({ operatorName: "", towerType: "", operationDate: new Date().toISOString().split("T")[0], operationTime: new Date().toTimeString().slice(0, 5), heads: "", tails: "", vinasse: "", vinasseLoading: "", alcohol96: "", convertedAlcohol: "", feedAmount: "", productionAmount: "", operationHours: "", }); setEditId(null); toast({ title: "نجح", description: "تم حفظ العملية بنجاح" }); }, onError: () => { toast({ title: "خطأ", description: "فشل في حفظ العملية", variant: "destructive", }); }, });

const deleteMutation = useMutation({ mutationFn: async (id: string) => { await deleteDoc(doc(db, "distillation-operations", id)); }, onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["distillation-operations"] }); toast({ title: "تم الحذف", description: "تم حذف العملية بنجاح" }); }, onError: () => { toast({ title: "خطأ", description: "حدث خطأ أثناء حذف العملية", variant: "destructive", }); }, });

const handleDelete = (id: string) => { if (confirm("هل أنت متأكد من حذف هذه العملية؟")) { deleteMutation.mutate(id); } };

const handleEdit = (operation: DistillationOperation) => { setFormData(operation); setEditId(operation.id); window.scrollTo({ top: 0, behavior: "smooth" }); };

const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); const feedAmount = parseFloat(formData.feedAmount || "0"); const productionAmount = parseFloat(formData.productionAmount || "0"); const operationHours = parseFloat(formData.operationHours || "0"); const feedRate = operationHours > 0 ? feedAmount / operationHours : null; const productionRate = operationHours > 0 ? productionAmount / operationHours : null;

const data: InsertDistillationOperation & { id?: string } = {
  ...formData,
  heads: formData.heads ? parseFloat(formData.heads) : null,
  tails: formData.tails ? parseFloat(formData.tails) : null,
  vinasse: formData.vinasse ? parseFloat(formData.vinasse) : null,
  vinasseLoading: formData.vinasseLoading ? parseFloat(formData.vinasseLoading) : null,
  alcohol96: formData.alcohol96 ? parseFloat(formData.alcohol96) : null,
  convertedAlcohol: formData.convertedAlcohol ? parseFloat(formData.convertedAlcohol) : null,
  feedAmount,
  productionAmount,
  operationHours,
  feedRate,
  productionRate,
  timestamp: new Date().toLocaleString("ar-EG"),
};

if (editId) data.id = editId;
saveMutation.mutate(data);

};

const handleExport = () => exportToExcel(operations, "distillation_operations");

const filteredOperations = useMemo(() => { return operations.filter((op) => { const matchShift = !searchFilters.shift || op.towerType === searchFilters.shift; const matchDate = !searchFilters.date || op.operationDate === searchFilters.date; return matchShift && matchDate; }); }, [operations, searchFilters]);

return ( <Card className="p-4 space-y-4"> <CardHeader> <CardTitle>سجل عمليات التقطير</CardTitle> </CardHeader> <CardContent> <form onSubmit={handleSubmit} className="space-y-4"> <div className="grid grid-cols-3 gap-4"> <div> <Label>اسم المشغل</Label> <Input value={formData.operatorName} onChange={(e) => setFormData({ ...formData, operatorName: e.target.value })} /> </div> <div> <Label>الوردية</Label> <Select value={formData.towerType} onValueChange={(val) => setFormData({ ...formData, towerType: val })}> <SelectTrigger><SelectValue placeholder="اختر الوردية" /></SelectTrigger> <SelectContent> <SelectItem value="الوردية الأولى">الوردية الأولى</SelectItem> <SelectItem value="الوردية الثانية">الوردية الثانية</SelectItem> <SelectItem value="الوردية الثالثة">الوردية الثالثة</SelectItem> </SelectContent> </Select> </div> <div> <Label>التاريخ</Label> <Input type="date" value={formData.operationDate} onChange={(e) => setFormData({ ...formData, operationDate: e.target.value })} /> </div> </div>

<div className="grid grid-cols-3 gap-4">
        <div><Label>هيدز (لتر)</Label><Input type="number" value={formData.heads} onChange={(e) => setFormData({ ...formData, heads: e.target.value })} /></div>
        <div><Label>زيت (لتر)</Label><Input type="number" value={formData.tails} onChange={(e) => setFormData({ ...formData, tails: e.target.value })} /></div>
        <div><Label>ڤيناس (م³)</Label><Input type="number" value={formData.vinasse} onChange={(e) => setFormData({ ...formData, vinasse: e.target.value })} /></div>
        <div><Label>تحميل ڤيناس (م³)</Label><Input type="number" value={formData.vinasseLoading} onChange={(e) => setFormData({ ...formData, vinasseLoading: e.target.value })} /></div>
        <div><Label>كحول 96%</Label><Input type="number" value={formData.alcohol96} onChange={(e) => setFormData({ ...formData, alcohol96: e.target.value })} /></div>
        <div><Label>كحول محول</Label><Input type="number" value={formData.convertedAlcohol} onChange={(e) => setFormData({ ...formData, convertedAlcohol: e.target.value })} /></div>
        <div><Label>كمية التغذية (hl)</Label><Input type="number" value={formData.feedAmount} onChange={(e) => setFormData({ ...formData, feedAmount: e.target.value })} /></div>
        <div><Label>كمية الإنتاج (hl)</Label><Input type="number" value={formData.productionAmount} onChange={(e) => setFormData({ ...formData, productionAmount: e.target.value })} /></div>
        <div><Label>عدد ساعات التشغيل</Label><Input type="number" value={formData.operationHours} onChange={(e) => setFormData({ ...formData, operationHours: e.target.value })} /></div>
      </div>
      <Button type="submit" className="w-full">حفظ البيانات</Button>
    </form>

    <div className="grid grid-cols-2 gap-4 mt-4">
      <div>
        <Label>تصفية حسب الوردية</Label>
        <Select value={searchFilters.shift} onValueChange={(val) => setSearchFilters((prev) => ({ ...prev, shift: val }))}>
          <SelectTrigger><SelectValue placeholder="الوردية" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="الوردية الأولى">الوردية الأولى</SelectItem>
            <SelectItem value="الوردية الثانية">الوردية الثانية</SelectItem>
            <SelectItem value="الوردية الثالثة">الوردية الثالثة</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>تصفية حسب التاريخ</Label>
        <Input type="date" value={searchFilters.date} onChange={(e) => setSearchFilters((prev) => ({ ...prev, date: e.target.value }))} />
      </div>
    </div>

    <div className="mt-4 space-y-2">
      {isLoading ? (
        <p>جارٍ التحميل...</p>
      ) : (
        filteredOperations.map((op) => (
          <div key={op.id} className="p-3 border rounded bg-muted">
            <p><strong>{op.operatorName}</strong> - {op.towerType}</p>
            <p className="text-sm text-muted-foreground">{op.operationDate} {op.operationTime}</p>
            <div className="grid grid-cols-2 text-sm gap-2 mt-2">
              <div>هيدز: {op.heads || 0} لتر</div>
              <div>زيت: {op.tails || 0} لتر</div>
              <div>ڤيناس: {op.vinasse || 0} م³</div>
              <div>تحميل ڤيناس: {op.vinasseLoading || 0} م³</div>
              <div>كحول 96%: {op.alcohol96 || 0} hl</div>
              <div>محول: {op.convertedAlcohol || 0} hl</div>
              <div>تغذية: {op.feedAmount || 0} hl</div>
              <div>إنتاج: {op.productionAmount || 0} hl</div>
              <div>الساعات: {op.operationHours || 0}</div>
              <div>معدل التغذية: {op.feedRate?.toFixed(2) || 0} hl/س</div>
              <div>معدل الإنتاج: {op.productionRate?.toFixed(2) || 0} hl/س</div>
            </div>
            <div className="flex justify-end gap-2 mt-2">
              <Button size="sm" variant="outline" onClick={() => handleEdit(op)}>تعديل</Button>
              <Button size="sm" variant="destructive" onClick={() => handleDelete(op.id)}>حذف</Button>
            </div>
          </div>
        ))
      )}
    </div>

    <div className="text-center mt-4">
      <Button onClick={handleExport} variant="outline" disabled={operations.length === 0}>
        <Download className="mr-2 h-4 w-4" /> تصدير إلى Excel
      </Button>
    </div>
  </CardContent>
</Card>

); }

